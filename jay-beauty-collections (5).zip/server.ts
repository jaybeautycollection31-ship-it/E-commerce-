import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import mongoose from "mongoose";
import { GoogleGenAI } from "@google/genai";
import nodemailer from "nodemailer";
import fs from "fs";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, doc, setDoc, getDocs, writeBatch, deleteDoc } from "firebase/firestore";

// Create a copy of the initial products to seed the database if it is empty.
const defaultProducts = [
  { "_id": "1", "name": "Premium Ladies Wear", "category": "Dresses", "price": 450, "image": "https://i.pinimg.com/736x/b9/a9/63/b9a963a89b5de4a6bea874edc7d25abe.jpg", "isNew": true, "stock": 15 },
  { "_id": "2", "name": "Premium Ladies Wear", "category": "Dresses", "price": 300, "image": "https://i.pinimg.com/736x/d8/55/fb/d855fb533f9bbbac35144f72f7e7ba15.jpg", "stock": 5 },
  { "_id": "3", "name": "Ladies Elegant Dress", "category": "Dresses", "price": 250, "image": "https://i.pinimg.com/736x/9e/3b/6b/9e3b6b7a1937d6312558d84683d4f746.jpg", "isBestSeller": true, "stock": 2 },
  { "_id": "4", "name": "Ladies Elegant Dress", "category": "Dresses", "price": 150, "image": "https://i.pinimg.com/736x/fa/a8/76/faa876a47ff7745dc217dd910bbfb9e4.jpg", "stock": 5 },
  { "_id": "5", "name": "Ladies Elegant Dress", "category": "Dresses", "price": 350, "image": "https://i.pinimg.com/736x/8e/9b/46/8e9b460ce991c78753a33338787fbf73.jpg", "stock": 10, "isNew": true },
  { "_id": "6", "name": "Elegant Pencil Dress", "category": "Dresses", "price": 600, "image": "https://i1-e.pinimg.com/1200x/c8/6e/0a/c86e0abc76dd43421a09464daef8d911.jpg", "stock": 8, "isBestSeller": true },
  { "_id": "7", "name": "Ladies Trousers", "category": "Bottoms", "price": 280, "image": "https://i1-e.pinimg.com/1200x/04/e5/5f/04e55f9aa90a52162399eda3262cd3c6.jpg", "stock": 12 },
  { "_id": "8", "name": "Premium Ladies Wear", "category": "Dresses", "price": 85, "image": "https://i.pinimg.com/736x/39/a2/d9/39a2d9d6ed46ce52a2151af266746b61.jpg", "stock": 20 },
  { "_id": "9", "name": "Men's Classic Long Sleeve", "category": "Men", "price": 120, "image": "https://i1-e.pinimg.com/1200x/17/08/75/170875303ece146efdc2bbb65bf29371.jpg", "stock": 18, "isNew": true },
  { "_id": "10", "name": "Men's Classic Long Sleeve", "category": "Men", "price": 295, "image": "https://i.pinimg.com/736x/d8/b9/d2/d8b9d2772572b01eeef0a5f7315d8257.jpg", "stock": 25 },
  { "_id": "11", "name": "Men's Casual Chinos", "category": "Bottoms", "price": 85, "image": "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=800", "stock": 30, "isBestSeller": true },
  { "_id": "12", "name": "Women Top and Down", "category": "Dresses", "price": 150, "image": "https://i.pinimg.com/736x/32/fe/3f/32fe3ffcc257317984c27e3b9ca08b49.jpg", "stock": 15 },
  { "_id": "13", "name": "Men's Classic Long Sleeve - Navy", "category": "Men", "price": 125, "image": "https://i1-e.pinimg.com/736x/00/29/49/002949123e5cff1b5319d80b6a322f6c.jpg", "stock": 20 },
  { "_id": "14", "name": "Men's Classic Long Sleeve - White", "category": "Men", "price": 110, "image": "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=800", "stock": 15 },
  { "_id": "15", "name": "Men's Classic Long Sleeve - Checkered", "category": "Men", "price": 130, "image": "https://i1-e.pinimg.com/1200x/40/fd/bf/40fdbf25b8fb9ea224343b88740f20d1.jpg", "stock": 12, "isNew": true },
  { "_id": "16", "name": "Men's Classic Long Sleeve - Striped", "category": "Men", "price": 135, "image": "https://i1-e.pinimg.com/1200x/37/58/07/3758072635fcdbc09451105ea0cc4059.jpg", "stock": 8 },
  { "_id": "17", "name": "Men's Classic Long Sleeve - Black", "category": "Men", "price": 120, "image": "https://i.pinimg.com/736x/84/fc/03/84fc0388b7b3bc2bcf5fae9f8417278f.jpg", "stock": 25, "isBestSeller": true },
  { "_id": "18", "name": "Women's Corporate Blouse", "category": "Tops", "price": 145, "image": "https://i.pinimg.com/736x/aa/3f/e1/aa3fe18582126885efdf344720fecbf8.jpg", "stock": 15, "isNew": true },
  { "_id": "19", "name": "Premium Ladies Wear", "category": "Dresses", "price": 210, "image": "https://i.pinimg.com/736x/96/6a/e3/966ae34453e23f8e5761a69ba1508c6f.jpg", "stock": 10, "isNew": true },
  { "_id": "20", "name": "Ladies Top and Down", "category": "Dresses", "price": 160, "image": "https://i1-e.pinimg.com/736x/87/2b/dc/872bdc19ba05e6fe828f62ed8670c79b.jpg", "stock": 15, "isNew": true },
  { "_id": "21", "name": "Ladies Top and Down", "category": "Dresses", "price": 175, "image": "https://i1-e.pinimg.com/736x/35/ba/a8/35baa8138dce0b0b78c1eb7fa8e68a25.jpg", "stock": 10, "isNew": true },
  { "_id": "22", "name": "Ladies Top and Down", "category": "Dresses", "price": 165, "image": "https://i1-e.pinimg.com/736x/26/a3/e9/26a3e9bd3fe2f51fa5cb3fbac793d152.jpg", "stock": 12, "isNew": true },
  { "_id": "23", "name": "Ladies High-Waisted Wide Legs Trousers", "category": "Bottoms", "price": 130, "image": "https://i.pinimg.com/736x/73/d4/7e/73d47e14916d1b84113117916b548195.jpg", "stock": 15, "isNew": true },
  { "_id": "24", "name": "Premium Ladies Wear", "category": "Dresses", "price": 250, "image": "https://i.pinimg.com/736x/fd/d2/6b/fdd26b30d44c9f508cc671977abab4be.jpg", "stock": 10, "isNew": true },
  { "_id": "25", "name": "Premium Ladies Wear", "category": "Dresses", "price": 220, "image": "https://i.pinimg.com/736x/d9/ad/62/d9ad628bb7a4248d9a8287dc7033c8ad.jpg", "stock": 8, "isNew": true },
  { "_id": "26", "name": "Ladies office wear", "category": "Dresses", "price": 210, "image": "https://i.pinimg.com/736x/5d/30/aa/5d30aad22c378442e1766520943457a2.jpg", "stock": 12, "isNew": true },
  { "_id": "27", "name": "Ladies Office wear", "category": "Dresses", "price": 230, "image": "https://i.pinimg.com/736x/ce/98/d4/ce98d4d699eacd7f999d2909dabd5aab.jpg", "stock": 10, "isNew": true },
  { "_id": "28", "name": "Ladies Office wear", "category": "Dresses", "price": 215, "image": "https://i1-e.pinimg.com/1200x/fe/9c/59/fe9c593e457071cfb3c04698c8a8dcf6.jpg", "stock": 15, "isNew": true },
  { "_id": "29", "name": "Premium Ladies Office Wear", "category": "Dresses", "price": 280, "image": "https://i.pinimg.com/736x/11/aa/10/11aa104557453741ed1a614200df93a4.jpg", "stock": 10, "isNew": true },
  { "_id": "30", "name": "Gent Top and Down", "category": "Men", "price": 180, "image": "https://i.pinimg.com/736x/8f/ef/cf/8fefcf955baed3abd579fc1511ce4833.jpg", "stock": 15, "isNew": true },
  { "_id": "31", "name": "Gent Top and Down", "category": "Men", "price": 195, "image": "https://i.pinimg.com/736x/16/9f/18/169f184a3fc6713adfd83d1247577eef.jpg", "stock": 12, "isNew": true },
  { "_id": "32", "name": "Gent Top and Down", "category": "Men", "price": 210, "image": "https://i1-e.pinimg.com/1200x/1f/9c/7b/1f9c7b0f8bb71196e2955fa48836b61f.jpg", "stock": 20, "isNew": true },
  { "_id": "33", "name": "Gent Top and Down", "category": "Men", "price": 220, "image": "https://i1-e.pinimg.com/736x/56/de/96/56de96a815ea817f328708d8b9cb46b2.jpg", "stock": 10, "isNew": true },
  { "_id": "34", "name": "Gent Top and Down", "category": "Men", "price": 200, "image": "https://i.pinimg.com/736x/b8/aa/18/b8aa18a48db1bcd0c8faf499afca4ed3.jpg", "stock": 18, "isNew": true },
  { "_id": "35", "name": "Men's Classic Long Sleeve", "category": "Men", "price": 120, "image": "https://i.pinimg.com/736x/25/5f/57/255f572c077ab467cf47329c25ec74eb.jpg", "stock": 15, "isNew": true },
  { "_id": "36", "name": "Ladies office wear", "category": "Dresses", "price": 180, "image": "https://i.pinimg.com/736x/f5/22/89/f522897a104f79f9f0a415fd75a8c45c.jpg", "stock": 15, "isNew": true },
  { "_id": "37", "name": "Ladies office wear", "category": "Dresses", "price": 170, "image": "https://i.pinimg.com/736x/a7/a6/cc/a7a6ccfc6fd0b8122af278f151c38211.jpg", "stock": 15, "isNew": true },
  { "_id": "38", "name": "Ladies office wear", "category": "Dresses", "price": 180, "image": "https://i.pinimg.com/736x/f5/22/89/f522897a104f79f9f0a415fd75a8c45c.jpg", "stock": 15, "isNew": true },
  { "_id": "39", "name": "Men's Trouser", "category": "Men", "price": 150, "image": "https://i.pinimg.com/736x/90/69/e1/9069e11a12c83885597c7dc314ff7ec9.jpg", "stock": 12, "isNew": true },
  { "_id": "40", "name": "Men's Trouser", "category": "Men", "price": 150, "image": "https://i.pinimg.com/736x/45/78/09/4578099e00c0e76bdfd191014e719864.jpg", "stock": 10, "isNew": true },
  { "_id": "41", "name": "Men's Lacoste", "category": "Men", "price": 150, "image": "https://i.pinimg.com/736x/0d/ef/ac/0defac44a67cb44048818594763c42ee.jpg", "stock": 15, "isNew": true },
  { "_id": "42", "name": "Men Lacoste", "category": "Men", "price": 150, "image": "https://i.pinimg.com/736x/d1/89/14/d189145c102fad176c150bf0242827d7.jpg", "stock": 15, "isNew": true },
];

async function startServer() {
  const app = express();
  const PORT = 3000;

  let db: any;
  try {
    const firebaseConfig = JSON.parse(fs.readFileSync(path.join(process.cwd(), "firebase-applet-config.json"), "utf8"));
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    console.log("Firebase initialized");
  } catch (err) {
    console.log("Warning: Failed to initialize Firebase", err);
  }

  // Seed default products to Firestore if empty
  const ensureProductsSeeded = async () => {
    try {
      const snap = await getDocs(collection(db, "products"));
      if (snap.empty) {
        console.log("Seeding products to Firestore...");
        const batch = writeBatch(db);
        defaultProducts.forEach(p => {
          const docRef = doc(db, "products", p._id);
          batch.set(docRef, p);
        });
        await batch.commit();
        console.log("Seeded default products to Firestore.");
      }
    } catch (err) {
      console.error("Failed to seed products:", err);
    }
  };
  ensureProductsSeeded();

  app.use(cors());
  app.use(express.json());

  app.get("/api/products", async (req, res) => {
    try {
      const snap = await getDocs(collection(db, "products"));
      const products = snap.docs.map(d => d.data());
      res.json(products);
    } catch (e) {
      console.error("Error fetching products:", e);
      res.status(500).json({ error: String(e) });
    }
  });

  app.post("/api/products", async (req, res) => {
    const { name, category, price, image, isVideo, stock, isNew, isBestSeller } = req.body;
    
    if (!name || !price) {
      return res.status(400).json({ error: "Name and price are required." });
    }

    const _id = Date.now().toString();
    const newProduct = {
      _id,
      name,
      category: category || 'General',
      price: Number(price),
      image: image || 'https://via.placeholder.com/800',
      isVideo: Boolean(isVideo),
      stock: Number(stock) || 0,
      isNew: Boolean(isNew),
      isBestSeller: Boolean(isBestSeller)
    };

    try {
      await setDoc(doc(db, "products", _id), newProduct);
      res.status(201).json(newProduct);
    } catch (e) {
      console.error("Error creating product:", e);
      res.status(500).json({ error: String(e) });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await deleteDoc(doc(db, "products", id));
      res.json({ success: true });
    } catch (e) {
      console.error("Error deleting product:", e);
      res.status(500).json({ error: String(e) });
    }
  });

  app.put("/api/products/bulk-update", async (req, res) => {
    const { updates } = req.body;
    if (!updates || !Array.isArray(updates)) {
      return res.status(400).json({ error: "Invalid payload" });
    }
    
    try {
      const batch = writeBatch(db);
      updates.forEach((update: any) => {
        if (update._id) {
          const docRef = doc(db, "products", update._id);
          const docUpdates: any = {};
          if (update.price !== undefined) docUpdates.price = Number(update.price);
          if (update.stock !== undefined) docUpdates.stock = Number(update.stock);
          if (update.name !== undefined) docUpdates.name = update.name;
          if (update.category !== undefined) docUpdates.category = update.category;
          if (update.image !== undefined) docUpdates.image = update.image;
          if (update.isVideo !== undefined) docUpdates.isVideo = update.isVideo;
          batch.update(docRef, docUpdates);
        }
      });
      await batch.commit();

      const snap = await getDocs(collection(db, "products"));
      const products = snap.docs.map(d => d.data());
      res.json({ success: true, products });
    } catch (e) {
      console.error("Error updating products:", e);
      res.status(500).json({ error: String(e) });
    }
  });

  // Chatbot Route using Gemini
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ reply: "Chatbot is offline. Gemini API Key missing." });
      }
      if (apiKey === "MY_GEMINI_API_KEY" || apiKey.includes("your-api-key")) {
        return res.status(500).json({ reply: "Oops! My API key is set to a placeholder (like 'MY_GEMINI_API_KEY'). 🛠️ Please open the Secrets menu in AI Studio and enter a real GEMINI_API_KEY, or delete the secret to use the default platform key." });
      }

      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `You are the customer service representative for Jay Beauty Collections, a high-end fashion boutique in Ghana. 
Answer questions politely, suggest products if asked, mention we deliver Accra-Winneba wide.
Customer: ${message}`,
      });

      res.json({ reply: response.text });
    } catch (err: any) {
      console.error('Chat error:', err);
      let errorMsg = "Sorry, I am having trouble connecting to my brain right now.";
      if (err?.message?.includes('API key not valid') || String(err).includes('API key not valid')) {
        errorMsg = "Oops! My API key is invalid. 🛠️ Please open the Secrets menu in AI Studio and enter a valid GEMINI_API_KEY. Alternatively, you can delete the secret entirely to let me use the default platform key.";
      }
      res.status(500).json({ reply: errorMsg });
    }
  });

  // Basic Order Mock
  app.post('/api/orders', (req, res) => {
    // Return a fake order complete
    res.json({ orderId: 'JBC-' + Math.floor(1000 + Math.random() * 9000), status: 'pending' });
  });

  // Setup Nodemailer transporter using Ethereal Email for testing in preview
  // or real SMTP credentials if provided
  let transporter: nodemailer.Transporter | null = null;
  
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === 'true' || process.env.SMTP_SECURE === 'SSL' || Number(process.env.SMTP_PORT) === 465,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
    console.log("Real Email transporter ready.");
  } else {
    nodemailer.createTestAccount().then((account) => {
      transporter = nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        secure: false,
        auth: {
          user: account.user,
          pass: account.pass,
        },
      });
      console.log("Mock Email transporter ready (Ethereal).");
    }).catch(err => console.error("Failed to create Ethereal account:", err));
  }

  const otpStore = new Map<string, string>();

  app.post('/api/auth/send-otp', async (req, res) => {
    if (!transporter) {
      return res.status(503).json({ error: 'Email service unavailable' });
    }

    const { email, type } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email address is required' });
    }

    // Generate a 6-digit OTP (or use a fixed one if no real SMTP is configured)
    const isEthereal = !process.env.SMTP_HOST || process.env.SMTP_HOST === 'smtp.ethereal.email';
    const otp = isEthereal ? '123456' : Math.floor(100000 + Math.random() * 900000).toString();
    otpStore.set(email, otp);

    const subject = type === 'signup' 
      ? 'Your verification code - Jay Beauty Collections' 
      : 'Your login code - Jay Beauty Collections';
      
    const text = `Your One-Time Password (OTP) is: ${otp}\nThis code will expire in 10 minutes.`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
        <h2 style="color: #6a1b9a;">${type === 'signup' ? 'Welcome to' : 'Login to'} Jay Beauty Collections</h2>
        <p>Please use the following One-Time Password (OTP) to complete your ${type}:</p>
        <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center;">
          <h1 style="color: #ea580c; margin: 0; letter-spacing: 5px;">${otp}</h1>
        </div>
        <p>This code is valid for 10 minutes. Do not share it with anyone.</p>
        <p>Best regards,<br>Jay Beauty Collections Team</p>
      </div>
    `;

    try {
      const info = await transporter.sendMail({
        from: process.env.SMTP_USER ? `"Jay Beauty Collections" <${process.env.SMTP_USER}>` : '"Jay Beauty Collections" <auth@jaybeautycollections.com>',
        to: email,
        subject: subject,
        text: text,
        html: html,
      });
      
      console.log('OTP sent: %s', info.messageId);
      if (isEthereal) {
        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
      }
      
      res.json({ success: true, message: 'OTP sent successfully', isDemo: isEthereal, demoOtp: isEthereal ? otp : undefined });
    } catch (error) {
      console.error('Error sending OTP email:', error);
      res.status(500).json({ error: 'Failed to send OTP - ' + (error instanceof Error ? error.message : String(error)) });
    }
  });

  app.post('/api/auth/verify-otp', (req, res) => {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP are required' });
    }

    const storedOtp = otpStore.get(email);
    if (!storedOtp || storedOtp !== otp) {
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }

    // Success - remove from store
    otpStore.delete(email);
    res.json({ success: true, message: 'OTP verified successfully' });
  });

  app.post('/api/orders/notify', async (req, res) => {
    if (!transporter) {
      return res.status(503).json({ error: 'Email service unavailable' });
    }

    const { orderId, type, email, customerName, status } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: 'Email address is required' });
    }

    let subject = '';
    let text = '';
    let html = '';

    if (type === 'confirmation') {
      subject = `Order Confirmation #${orderId} - Jay Beauty Collections`;
      text = `Hello ${customerName},\n\nThank you for your order!\nYour order ID is: ${orderId}\nWe have received your request and our admin will process it shortly.\n\nBest regards,\nJay Beauty Collections Team`;
      html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
          <h2 style="color: #6a1b9a;">Order Confirmation</h2>
          <p>Hello <strong>${customerName}</strong>,</p>
          <p>Thank you for choosing Jay Beauty Collections! We've received your order.</p>
          <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p style="margin: 0;"><strong>Order ID:</strong> ${orderId}</p>
            <p style="margin: 0; margin-top: 5px;"><strong>Status:</strong> Pending</p>
          </div>
          <p>We'll notify you once your order's status changes or when it's shipped.</p>
          <p>Best regards,<br>Jay Beauty Collections Team</p>
        </div>
      `;
    } else if (type === 'status_update') {
      subject = `Order Status Update #${orderId} - Jay Beauty Collections`;
      text = `Hello ${customerName},\n\nYour order #${orderId} status has been updated to: ${status}.\n\nBest regards,\nJay Beauty Collections Team`;
      html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
          <h2 style="color: #6a1b9a;">Order Status Update</h2>
          <p>Hello <strong>${customerName}</strong>,</p>
          <p>There is an update regarding your recent order.</p>
          <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p style="margin: 0;"><strong>Order ID:</strong> ${orderId}</p>
            <p style="margin: 0; margin-top: 5px;"><strong>New Status:</strong> <span style="color: #ea580c; font-weight: bold;">${status}</span></p>
          </div>
          <p>If you have any questions, feel free to contact us.</p>
          <p>Best regards,<br>Jay Beauty Collections Team</p>
        </div>
      `;
    } else {
      return res.status(400).json({ error: 'Invalid notification type' });
    }

    try {
      const info = await transporter.sendMail({
        from: process.env.SMTP_USER ? `"Jay Beauty Collections" <${process.env.SMTP_USER}>` : '"Jay Beauty Collections" <orders@jaybeautycollections.com>', // sender address
        to: email, // list of receivers
        subject: subject, // Subject line
        text: text, // plain text body
        html: html, // html body
      });

      console.log('Message sent: %s', info.messageId);
      // Preview only available when sending through an Ethereal account
      if (process.env.SMTP_HOST === undefined || process.env.SMTP_HOST === '') {
        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
      }
      
      res.json({ success: true, messageId: info.messageId });
    } catch (error) {
      console.error('Error sending email:', error);
      res.status(500).json({ error: 'Failed to send email' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // Since we are using express 4.x as per package.json, we use app.get('*', ...)
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
