fetch('http://localhost:3000/api/products')
  .then(res => res.text())
  .then(data => console.log('Products:', data))
  .catch(err => console.error(err));
