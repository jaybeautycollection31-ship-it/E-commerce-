import { Link, useNavigate } from 'react-router';
import { Trash2, Plus, Minus, ArrowRight, CheckCircle2, AlertCircle, XCircle } from 'lucide-react';
import { useStore } from '../store/useStore';
import MediaDisplay from '../components/MediaDisplay';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity } = useStore();
  const navigate = useNavigate();

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const total = subtotal;

  if (cart.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
        <h2 className="text-2xl font-bold mb-4">Your Cart is Empty</h2>
        <p className="text-gray-500 mb-8 text-center max-w-sm">Looks like you haven't added anything to your cart yet. Discover your next favorite outfit.</p>
        <Link to="/shop" className="bg-primary-900 text-white px-8 py-3 rounded-full hover:bg-primary-800 transition-colors font-medium">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold tracking-tight mb-8">Shopping Cart</h1>
      
      <div className="flex flex-col lg:flex-row gap-12">
        {/* Cart Items */}
        <div className="flex-1">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 sm:p-8 space-y-8">
              {cart.map((item) => (
                <div key={item._id} className="flex flex-col sm:flex-row items-start sm:items-center gap-6 pb-8 border-b border-gray-100 last:border-0 last:pb-0">
                  <Link to={`/product/${item._id}`} className="w-24 h-32 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <MediaDisplay src={item.image} alt={item.name} isVideo={item.isVideo} className="w-full h-full object-cover" />
                  </Link>
                  
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-bold text-lg text-primary-900">{item.name}</h3>
                        <p className="text-sm text-gray-500 mb-1">Size: M</p>
                        {(item.stock ?? 10) > 5 ? (
                          <p className="text-xs text-green-600 flex items-center gap-1 font-medium"><CheckCircle2 className="w-3 h-3" /> In Stock</p>
                        ) : (item.stock ?? 10) > 0 ? (
                          <p className="text-xs text-yellow-600 flex items-center gap-1 font-medium"><AlertCircle className="w-3 h-3" /> Low Stock ({(item.stock ?? 10)} left)</p>
                        ) : (
                          <p className="text-xs text-red-600 flex items-center gap-1 font-medium"><XCircle className="w-3 h-3" /> Out of Stock</p>
                        )}
                      </div>
                      <span className="font-bold">GH₵ {(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                    
                    <div className="flex justify-between items-center mt-4">
                      <div className="flex items-center border border-gray-200 rounded-full bg-white">
                        <button 
                          onClick={() => updateQuantity(item._id, Math.max(1, item.quantity - 1))}
                          className="p-2 hover:bg-gray-50 rounded-l-full text-gray-500"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="w-12 text-center font-medium">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item._id, item.quantity + 1)}
                          className="p-2 hover:bg-gray-50 rounded-r-full text-gray-500"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                      <button 
                        onClick={() => removeFromCart(item._id)}
                        className="text-red-500 p-2 hover:bg-red-50 rounded-full transition-colors"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="w-full lg:w-96">
          <div className="bg-gray-50 rounded-2xl p-8 sticky top-24">
            <h2 className="text-xl font-bold mb-6 pb-4 border-b border-gray-200">Order Summary</h2>
            
            <div className="space-y-4 mb-6 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span className="font-medium">GH₵ {subtotal.toFixed(2)}</span>
              </div>
              <p className="text-[10px] text-gray-600 mt-1 font-bold italic">
                * Delivery price is based on distance
              </p>
            </div>
            
            <div className="flex justify-between items-center mb-8 pt-6 border-t border-gray-200">
              <span className="font-bold text-lg">Total</span>
              <span className="font-bold text-2xl text-accent-orange">GH₵ {total.toFixed(2)}</span>
            </div>
            
            <button 
              onClick={() => navigate('/checkout')}
              className="w-full bg-primary-900 text-white py-4 rounded-full font-bold hover:bg-primary-800 transition-colors flex items-center justify-center gap-2 shadow-lg"
            >
              Proceed to Checkout <ArrowRight className="h-5 w-5" />
            </button>
            <p className="text-center text-xs text-gray-500 mt-4 px-4">
              Shipping & taxes calculated at checkout. Secure your order through our direct checkout.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
