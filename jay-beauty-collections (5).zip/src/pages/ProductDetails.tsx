import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router';
import { ArrowLeft, Star, ShoppingBag, Truck, ShieldCheck, Heart, MessageCircle } from 'lucide-react';
import { Product, useStore } from '../store/useStore';
import MediaDisplay from '../components/MediaDisplay';
import { db } from '../lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';

export default function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [size, setSize] = useState('M');
  
  const addToCart = useStore(state => state.addToCart);

  useEffect(() => {
    if (!id) return;
    const unsub = onSnapshot(doc(db, "products", id), (snap) => {
      if (snap.exists()) {
        setProduct({ _id: snap.id, ...snap.data() } as Product);
      }
      setLoading(false);
    });
    return unsub;
  }, [id]);

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center">Loading...</div>;
  if (!product) return <div className="min-h-[60vh] flex items-center justify-center">Product not found</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link to="/shop" className="inline-flex items-center text-sm font-medium text-gray-500 hover:text-primary-900 mb-8 transition-colors">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Shop
      </Link>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24">
        {/* Images */}
        <div className="space-y-4">
          <div className="aspect-[4/5] bg-gray-100 rounded-2xl overflow-hidden">
            <MediaDisplay src={product.image} alt={product.name} isVideo={product.isVideo} className="w-full h-full object-cover" />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(idx => (
              <div key={idx} className="aspect-square bg-gray-100 rounded-lg overflow-hidden cursor-pointer hover:opacity-80 transition-opacity">
                 <MediaDisplay src={product.image} alt={product.name} isVideo={product.isVideo} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Details */}
        <div className="flex flex-col">
          <p className="text-sm font-medium text-accent-orange uppercase tracking-widest mb-2">{product.category}</p>
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight text-primary-900 mb-4">{product.name}</h1>
          <div className="flex items-center gap-4 mb-6">
            <span className="text-2xl font-bold">GH₵ {product.price.toFixed(2)}</span>
            <div className="flex items-center text-sm text-gray-500">
              <div className="flex text-yellow-400 mr-2">
                {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
              </div>
              (124 reviews)
            </div>
          </div>

          <p className="text-gray-600 leading-relaxed mb-8">
            Elevate your wardrobe with our premium {product.name.toLowerCase()}. Crafted with exquisite detail and high-quality fabric, this piece is designed to offer both style and comfort. Perfect for any modern occasion.
          </p>

          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-primary-900">Select Size</h3>
              <button className="text-sm text-gray-500 underline">Size Guide</button>
            </div>
            <div className="grid grid-cols-4 gap-4">
              {['S', 'M', 'L', 'XL'].map(s => (
                <button 
                  key={s} 
                  onClick={() => setSize(s)}
                  className={`py-3 border-2 rounded-xl text-center font-medium transition-colors
                    ${size === s ? 'border-primary-900 text-primary-900' : 'border-gray-200 text-gray-500 hover:border-gray-300'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4 mb-12">
            <div className="flex gap-4">
              <button 
                onClick={() => addToCart(product)}
                className="flex-1 bg-primary-900 text-white py-4 rounded-full font-bold text-lg hover:bg-primary-800 transition-colors flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
              >
                <ShoppingBag className="h-5 w-5" /> Add to Cart
              </button>
              <button className="p-4 border-2 border-gray-200 rounded-full hover:border-accent-orange hover:text-accent-orange transition-colors">
                <Heart className="h-6 w-6" />
              </button>
            </div>
            <button 
              onClick={() => {
                const randomOrderId = 'JBC-' + Math.random().toString(10).substring(2, 6).toUpperCase();
                const message = encodeURIComponent(`Hi, I would like to order: ${product.name} (GH₵${product.price.toFixed(2)}) - Size: ${size}\nOrder ID: ${randomOrderId}`);
                window.open(`https://wa.me/233548630196?text=${message}`, '_blank');
              }}
              className="w-full bg-[#25D366] text-white py-4 rounded-full font-bold text-lg hover:bg-[#128C7E] transition-colors flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
            >
              <div className="h-8 w-8 rounded-full overflow-hidden mr-2 flex items-center justify-center">
                <img src="https://i1-e.pinimg.com/1200x/2f/e7/7c/2fe77c40e6ab4b44b8fe4f9e0334f403.jpg" alt="WhatsApp" className="h-full w-full object-cover scale-150" /> 
              </div>
              Order via WhatsApp
            </button>
          </div>

          <div className="border-t border-gray-100 pt-8 space-y-4">
            <div className="flex items-start gap-4">
              <div className="bg-gray-50 p-3 rounded-full">
                <Truck className="h-6 w-6 text-gray-600" />
              </div>
              <div>
                <h4 className="font-bold text-primary-900">Free Delivery</h4>
                <p className="text-sm text-gray-500 mt-1">Available across Accra and Winneba. Typically arrives in 2-3 days.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-gray-50 p-3 rounded-full">
                <ShieldCheck className="h-6 w-6 text-gray-600" />
              </div>
              <div>
                <h4 className="font-bold text-primary-900">Secure Payments</h4>
                <p className="text-sm text-gray-500 mt-1">Pay comfortably via MTN MoMo, Telecel Cash, or Visa/Mastercard.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
