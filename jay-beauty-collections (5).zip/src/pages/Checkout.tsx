import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Lock, ShieldCheck, CheckCircle } from 'lucide-react';
import { useStore } from '../store/useStore';
import MediaDisplay from '../components/MediaDisplay';
import { db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

export default function Checkout() {
  const { cart, clearCart, addOrder } = useStore();
  const navigate = useNavigate();
  const [complete, setComplete] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [loading, setLoading] = useState(false);

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const total = subtotal;

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const firstName = formData.get('firstName');
    const lastName = formData.get('lastName');
    const phone = formData.get('phone');
    const street = formData.get('street');
    const city = formData.get('city');
    const gps = formData.get('gps');
    const email = formData.get('email') as string;

    const randomOrderId = 'JBC-' + Math.random().toString(10).substring(2, 6).toUpperCase();
    
    let orderMessage = `*New Order from ${firstName} ${lastName}*\n`;
    orderMessage += `*Order ID: ${randomOrderId}*\n\n`;
    orderMessage += `*Delivery Details:*\n`;
    orderMessage += `Phone: ${phone}\n`;
    orderMessage += `Address: ${street}, ${city}\n`;
    if (gps) orderMessage += `GPS: ${gps}\n`;
    orderMessage += `\n*Order Items:*\n`;

    cart.forEach(item => {
      orderMessage += `- ${item.quantity}x ${item.name} (GH₵${item.price.toFixed(2)})\n`;
    });

    orderMessage += `\n*Subtotal:* GH₵${subtotal.toFixed(2)}\n`;
    orderMessage += `*Total:* GH₵${total.toFixed(2)}\n`;

    const newOrder = {
      id: randomOrderId,
      customer: `${firstName} ${lastName?.toString().charAt(0)}.`,
      email,
      date: new Date().toISOString().split('T')[0],
      status: 'Pending' as const,
      total: total,
      items: cart
    };

    try {
      console.log("Saving order to Firebase:", randomOrderId);
      await setDoc(doc(db, "orders", randomOrderId), newOrder);
      console.log("Order saved successfully");
    } catch (err) {
      console.error('Failed to save order to Firebase', err);
      // We don't want to block the whole process if only Firebase fails, 
      // but we should at least know about it.
      // In a real app, you might want to warn the user that tracking will be unavailable.
    }

    // Send email notification via backend
    try {
      await fetch('/api/orders/notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: randomOrderId,
          type: 'confirmation',
          email,
          customerName: `${firstName} ${lastName}`,
          status: 'Pending'
        })
      });
    } catch (error) {
      console.error('Failed to send notification', error);
    }

    addOrder(newOrder);
    setOrderId(randomOrderId);
    clearCart();
    setComplete(true);
    setLoading(false);

    const encodedMessage = encodeURIComponent(orderMessage);
    const adminPhone = "233548630196"; // Replace with your actual WhatsApp number

    setTimeout(() => {
      window.open(`https://wa.me/${adminPhone}?text=${encodedMessage}`, '_blank');
    }, 100);
  };

  if (complete) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4">
        <CheckCircle className="h-20 w-20 text-accent-green mb-6" />
        <h1 className="text-3xl font-bold tracking-tight mb-2">Order Confirmed!</h1>
        <p className="text-gray-500 text-center mb-6">Thank you for shopping with Jay Beauty Collections.</p>
        <div className="bg-gray-50 p-6 rounded-2xl w-full max-w-md mb-8 text-center border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">Your Order ID is</p>
          <p className="text-2xl font-mono font-bold text-primary-900">{orderId}</p>
        </div>
        <p className="text-sm text-gray-500 mb-8 max-w-md text-center">
          We have sent a confirmation email & Hubtel SMS to your phone. You can track your order using this ID.
        </p>
        <button 
          onClick={() => navigate('/track')}
          className="bg-primary-900 text-white px-8 py-3 rounded-full hover:bg-primary-800 transition-colors font-medium mb-4"
        >
          Track Order
        </button>
      </div>
    );
  }

  if (cart.length === 0) return <div className="text-center p-12">Cart is empty. Redirecting...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col lg:flex-row gap-12">
        
        {/* Form */}
        <div className="flex-1">
          <h1 className="text-3xl font-bold tracking-tight mb-8 hidden lg:block">Secure Checkout</h1>
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-bold mb-6 pb-2 border-b border-gray-100">Contact Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">First Name</label>
                  <input name="firstName" required type="text" className="w-full border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:border-primary-900" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Last Name</label>
                  <input name="lastName" required type="text" className="w-full border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:border-primary-900" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <input name="email" type="email" className="w-full border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:border-primary-900" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-2">Phone Number (For WhatsApp Updates)</label>
                  <input name="phone" required type="tel" placeholder="+233" className="w-full border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:border-primary-900" />
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-bold mb-6 pb-2 border-b border-gray-100">Delivery Address</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-2">Street Address</label>
                  <input name="street" required type="text" className="w-full border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:border-primary-900" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">City/Region</label>
                  <select name="city" className="w-full border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:border-primary-900 bg-white">
                    <option>Accra</option>
                    <option>Winneba</option>
                    <option>Other (Contact us)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Digital Address (GhanaPostGPS)</label>
                  <input name="gps" type="text" placeholder="e.g. GA-100-1111" className="w-full border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:border-primary-900" />
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex items-center gap-2 mb-6 pb-2 border-b border-gray-100">
                <ShieldCheck className="h-6 w-6 text-accent-green" />
                <h2 className="text-xl font-bold">Complete Order via WhatsApp</h2>
              </div>
              <p className="text-sm text-gray-500 mb-6">You will be redirected to WhatsApp to send your order details to our admin to arrange payment and delivery.</p>
              
              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white py-4 rounded-xl font-bold text-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-75"
              >
                {loading ? 'Processing...' : <><Lock className="h-5 w-5" /> Order on WhatsApp (GH₵ {total.toFixed(2)})</>}
              </button>
            </div>
          </form>
        </div>

        {/* Sidebar Summary */}
        <div className="w-full lg:w-96 order-first flex-shrink-0 lg:order-last">
          <h1 className="text-3xl font-bold tracking-tight mb-8 block lg:hidden">Secure Checkout</h1>
          <div className="bg-gray-50 rounded-2xl p-6 md:p-8 sticky top-24">
            <h2 className="text-lg font-bold mb-6">Order Details</h2>
            <div className="space-y-4 mb-6">
              {cart.map(item => (
                <div key={item._id} className="flex gap-4">
                  <div className="relative w-16 h-20 bg-gray-200 rounded-md overflow-hidden flex-shrink-0">
                    <MediaDisplay src={item.image} alt={item.name} isVideo={item.isVideo} className="w-full h-full object-cover" />
                    <span className="absolute -top-2 -right-2 bg-gray-500 text-white w-5 h-5 flex justify-center items-center rounded-full text-[10px] font-bold">
                      {item.quantity}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm line-clamp-2">{item.name}</p>
                    <p className="text-gray-500 text-xs mt-1">Size: M</p>
                  </div>
                  <div className="font-semibold text-sm">GH₵ {(item.price * item.quantity).toFixed(2)}</div>
                </div>
              ))}
            </div>
            
            <div className="border-t border-gray-200 pt-4 space-y-3 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span className="font-medium">GH₵ {subtotal.toFixed(2)}</span>
              </div>
              <p className="text-[10px] text-gray-600 mt-1 font-bold italic">
                * Delivery price is based on distance
              </p>
              <div className="flex justify-between items-center pt-4 border-t border-gray-200">
                <span className="font-bold text-lg">Total</span>
                <span className="font-bold text-xl text-primary-900">GH₵ {total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
