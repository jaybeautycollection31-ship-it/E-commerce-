import React, { useState } from 'react';
import { Package, Truck, CheckCircle2, Home } from 'lucide-react';
import { useStore, Order } from '../store/useStore';
import { db } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

export default function OrderTracking() {
  const [orderId, setOrderId] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanId = orderId.trim();
    if(cleanId) {
      setLoading(true);
      setError('');
      try {
        let docId = cleanId.toUpperCase();
        if (!docId.startsWith('JBC-')) {
          docId = 'JBC-' + docId;
        }
        console.log("Tracking order with ID:", docId);
        const orderDoc = await getDoc(doc(db, "orders", docId));
        
        if (orderDoc.exists()) {
          console.log("Order found:", orderDoc.id);
          setTrackedOrder(orderDoc.data() as Order);
        } else {
          console.log("Order not found in Firestore");
          setTrackedOrder(null);
          setError('Order not found. Please ensure the ID is correct (including JBC-).');
        }
      } catch (err) {
        console.error("Firestore Error in handleTrack:", err);
        setTrackedOrder(null);
        
        // Detailed error for debugging
        const errorMessage = err instanceof Error ? err.message : String(err);
        if (errorMessage.includes('permission')) {
          setError('Access denied. Security rules might be blocking the request.');
        } else if (errorMessage.includes('offline') || errorMessage.includes('failed to connect')) {
          setError('Network error. Please check your internet connection.');
        } else {
          setError(`Error: ${errorMessage}`);
        }
      } finally {
        setLoading(false);
      }
    }
  };

  const getStatusLevel = (status: string) => {
    switch (status) {
      case 'Pending': return 1;
      case 'Processing': return 2;
      case 'Shipped': return 3;
      case 'Out for Delivery': return 4;
      case 'Delivered': return 5;
      default: return 1;
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-24 min-h-[70vh]">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Track Your Order</h1>
        <p className="text-gray-500">Enter your order ID from your confirmation email or SMS to see real-time status.</p>
      </div>

      <form onSubmit={handleTrack} className="flex flex-col gap-4 max-w-xl mx-auto mb-16">
        <div className="flex gap-4">
          <input 
            type="text" 
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            placeholder="e.g. JBC-4829" 
            required
            className="flex-1 border border-gray-200 rounded-full px-6 py-4 focus:outline-none focus:border-primary-900 shadow-sm"
          />
          <button 
            type="submit"
            disabled={loading}
            className="bg-primary-900 text-white px-8 py-4 rounded-full font-bold hover:bg-primary-800 transition-colors shadow-sm disabled:opacity-70 flex items-center justify-center min-w-[120px]"
          >
            {loading ? 'Tracking...' : 'Track'}
          </button>
        </div>
        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
      </form>

      {trackedOrder && (
        <div className="bg-white border border-gray-100 rounded-3xl p-8 md:p-12 shadow-sm max-w-2xl mx-auto relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-accent-orange"></div>
          
          <div className="flex justify-between items-center mb-12">
            <div>
              <p className="text-sm text-gray-500 mb-1">Order ID</p>
              <p className="text-xl font-bold font-mono">{trackedOrder.id}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500 mb-1">Status</p>
              <p className="text-xl font-bold text-accent-green">{trackedOrder.status}</p>
            </div>
          </div>

          <div className="relative">
            {/* Connecting line */}
            <div className="absolute left-[28px] top-6 bottom-6 w-1 bg-gray-100 rounded-full"></div>
            
            {/* Steps */}
            <div className="space-y-8">
              {/* Step 1: Confirmed */}
              <div className={`flex items-start gap-6 relative z-10 ${getStatusLevel(trackedOrder.status) >= 1 ? '' : 'opacity-40 grayscale'}`}>
                <div className={`w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 ${getStatusLevel(trackedOrder.status) >= 1 ? 'bg-accent-green text-white' : 'bg-gray-200 text-gray-500 border-4 border-white'}`}>
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <div className="pt-3">
                  <h3 className="font-bold text-lg">Order Confirmed</h3>
                  <p className="text-sm text-gray-500">Your order has been received and payment confirmed.</p>
                </div>
              </div>
              
              {/* Step 2: Processing */}
              <div className={`flex items-start gap-6 relative z-10 ${getStatusLevel(trackedOrder.status) >= 2 ? '' : 'opacity-40 grayscale'}`}>
                <div className={`w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 ${getStatusLevel(trackedOrder.status) === 2 ? 'bg-accent-orange text-white shadow-lg shadow-orange-200' : getStatusLevel(trackedOrder.status) > 2 ? 'bg-accent-green text-white' : 'bg-gray-200 text-gray-500 border-4 border-white'}`}>
                  <Package className="h-6 w-6" />
                </div>
                <div className="pt-3">
                  <h3 className={`font-bold text-lg ${getStatusLevel(trackedOrder.status) === 2 ? 'text-primary-900' : ''}`}>Processing</h3>
                  <p className="text-sm text-gray-500">We are preparing your items for shipping.</p>
                </div>
              </div>

              {/* Step 3 & 4: Out for Delivery */}
              <div className={`flex items-start gap-6 relative z-10 ${getStatusLevel(trackedOrder.status) >= 3 ? '' : 'opacity-40 grayscale'}`}>
                <div className={`w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 ${getStatusLevel(trackedOrder.status) === 3 || getStatusLevel(trackedOrder.status) === 4 ? 'bg-accent-orange text-white shadow-lg shadow-orange-200' : getStatusLevel(trackedOrder.status) > 4 ? 'bg-accent-green text-white' : 'bg-gray-200 text-gray-500 border-4 border-white'}`}>
                  <Truck className="h-6 w-6" />
                </div>
                <div className="pt-3">
                  <h3 className={`font-bold text-lg ${getStatusLevel(trackedOrder.status) >= 3 && getStatusLevel(trackedOrder.status) <= 4 ? 'text-primary-900' : ''}`}>Out for Delivery</h3>
                  <p className="text-sm text-gray-500">Rider is on the way to your location.</p>
                </div>
              </div>

              {/* Step 5: Delivered */}
              <div className={`flex items-start gap-6 relative z-10 ${getStatusLevel(trackedOrder.status) >= 5 ? '' : 'opacity-40 grayscale'}`}>
                <div className={`w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 ${getStatusLevel(trackedOrder.status) >= 5 ? 'bg-accent-green text-white shadow-lg shadow-green-200' : 'bg-gray-200 text-gray-500 border-4 border-white'}`}>
                  <Home className="h-6 w-6" />
                </div>
                <div className="pt-3">
                  <h3 className={`font-bold text-lg ${getStatusLevel(trackedOrder.status) >= 5 ? 'text-primary-900' : ''}`}>Delivered</h3>
                  <p className="text-sm text-gray-500">Enjoy your purchase!</p>
                </div>
              </div>
            </div>
            
            <div className="mt-12 pt-8 border-t border-gray-100">
               <h4 className="font-bold mb-4">Order Summary</h4>
               <div className="flex justify-between text-sm mb-1">
                 <span className="text-gray-500">Total</span>
                 <span className="font-bold">GH₵ {trackedOrder.total.toFixed(2)}</span>
               </div>
               <p className="text-[10px] text-gray-600 font-bold italic mt-2">
                 * Delivery price is based on distance
               </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
