import { useEffect, useState } from 'react';
import { ArrowRight, Star, MessageCircle } from 'lucide-react';
import { Link } from 'react-router';
import { Product, useStore } from '../store/useStore';
import { motion } from 'motion/react';
import MediaDisplay from '../components/MediaDisplay';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, limit } from 'firebase/firestore';

export default function Home() {
  const [featured, setFeatured] = useState<Product[]>([]);
  const addToCart = useStore(state => state.addToCart);

  useEffect(() => {
    const q = query(collection(db, "products"), limit(8));
    const unsub = onSnapshot(q, (snap) => {
      const fbProducts = snap.docs.map(d => ({ 
        _id: d.id, 
        ...d.data() 
      } as Product));
      setFeatured(fbProducts);
    });
    return unsub;
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-primary-900/40 z-10" /> {/* Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1520006403909-838d6b92c22e?auto=format&fit=crop&w=1200&q=70")' }}
        />
        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight leading-tight"
          >
            Express Your <br/><span className="text-accent-orange italic pr-4">Authentic</span> Style
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl text-gray-200 mb-10 max-w-2xl mx-auto"
          >
            Premium, curated fashion for the modern Ghanaian. High-end modern boutique meets seamless online shopping.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Link to="/shop" className="inline-flex items-center justify-center bg-white text-primary-900 hover:bg-gray-100 font-medium px-8 py-4 rounded-full transition-transform hover:scale-105 shadow-lg">
              Shop New Arrivals <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-primary-900">Featured Categories</h2>
          <Link to="/shop" className="text-accent-orange font-medium hover:underline hidden sm:block">View all categories</Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: 'Women', image: 'https://i1-e.pinimg.com/1200x/f9/f3/fa/f9f3fa975852bdc63dfb37d0637c5708.jpg' },
            { name: 'Men', image: 'https://i1-e.pinimg.com/736x/03/7d/76/037d7627a8270f356d441f441c53bc0b.jpg' },
            { name: 'Women Corporate Blouse', image: 'https://i1-e.pinimg.com/1200x/2a/f6/fb/2af6fb0e3234c697340cdd180175f506.jpg' },
          ].map((cat, idx) => (
            <Link to={`/shop?category=${cat.name}`} key={idx} className="group relative h-96 overflow-hidden rounded-2xl cursor-pointer">
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors z-10" />
              <img 
                src={cat.image} 
                alt={cat.name} 
                referrerPolicy="no-referrer" 
                loading="lazy" 
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
              />
              <div className="absolute bottom-8 left-8 z-20">
                <h3 className="text-2xl font-bold text-white mb-2">{cat.name}</h3>
                <span className="text-white hover:text-accent-orange flex items-center text-sm font-medium uppercase tracking-widest">
                  Shop Now <ArrowRight className="ml-2 h-4 w-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* New Arrivals & Best Sellers Grid */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-primary-900 mb-4">Trending Now</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Discover the latest pieces loved by our customers across Ghana.</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featured.map((product) => (
              <div key={product._id} className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300">
                <Link to={`/product/${product._id}`} className="block relative aspect-[3/4] overflow-hidden bg-gray-100">
                  <MediaDisplay src={product.image} alt={product.name} isVideo={product.isVideo} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  {product.isNew && (
                    <div className="absolute top-4 left-4 bg-primary-900 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">New</div>
                  )}
                  {product.isBestSeller && (
                    <div className="absolute top-4 left-4 bg-accent-orange text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">Best Seller</div>
                  )}
                </Link>
                <div className="p-6">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{product.category}</p>
                  <Link to={`/product/${product._id}`} className="block">
                    <h3 className="text-lg font-bold text-primary-900 mb-2 truncate">{product.name}</h3>
                  </Link>
                  <div className="flex justify-between items-center mt-4">
                    <span className="font-semibold text-lg text-primary-900">GH₵ {product.price.toFixed(2)}</span>
                    <div className="flex gap-2">
                      <button 
                        onClick={(e) => { 
                          e.preventDefault();
                          const randomOrderId = 'JBC-' + Math.random().toString(10).substring(2, 6).toUpperCase();
                          const message = encodeURIComponent(`Hi, I would like to order: ${product.name} (GH₵${product.price.toFixed(2)})\nOrder ID: ${randomOrderId}`);
                          window.open(`https://wa.me/233548630196?text=${message}`, '_blank');
                        }}
                        className="bg-[#25D366] hover:bg-[#128C7E] text-white p-0 h-10 w-10 flex items-center justify-center rounded-full transition-colors shadow-sm overflow-hidden"
                        title="Order via WhatsApp"
                      >
                        <img src="https://i1-e.pinimg.com/1200x/2f/e7/7c/2fe77c40e6ab4b44b8fe4f9e0334f403.jpg" alt="WhatsApp" className="h-full w-full object-cover scale-150" />
                      </button>
                      <button 
                        onClick={(e) => { e.preventDefault(); addToCart(product); }}
                        className="bg-gray-100 hover:bg-accent-orange hover:text-white p-3 rounded-full transition-colors shadow-sm"
                        title="Add to Cart"
                      >
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold tracking-tight text-primary-900 text-center mb-16">Loved by Customers</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { text: "Fast delivery to Winneba! The dress fits perfectly and the fabric is premium quality.", author: "Ama D." },
            { text: "Jay Beauty Collections is my go-to for all my outfits. Customer support via WhatsApp was very helpful.", author: "Kwame K." },
            { text: "I highly recommend! The checkout with MTN Mobile Money was seamless.", author: "Grace T." }
          ].map((t, idx) => (
            <div key={idx} className="bg-white border border-gray-100 p-8 rounded-2xl shadow-sm">
              <div className="flex text-accent-orange mb-6">
                {[...Array(5)].map((_, i) => <Star key={i} className="h-5 w-5 fill-current" />)}
              </div>
              <p className="text-gray-700 italic mb-6 leading-relaxed">"{t.text}"</p>
              <p className="font-bold text-primary-900">— {t.author}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
