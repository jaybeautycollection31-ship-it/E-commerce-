import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'bot' | 'user', text: string}[]>([
    { role: 'bot', text: 'Hello! How can I help you find the perfect outfit today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userText = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userText })
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: 'bot', text: data.reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'bot', text: 'Sorry, I am having trouble answering right now.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Buttons */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
        <a 
          href="https://wa.me/233548630196" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform flex items-center justify-center cursor-pointer"
        >
          <MessageCircle className="h-6 w-6" />
        </a>
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="bg-primary-900 text-white p-4 rounded-full shadow-lg hover:bg-primary-800 hover:scale-110 transition-transform flex items-center justify-center"
        >
          {isOpen ? <X className="h-6 w-6" /> : <span className="font-bold tracking-tighter">AI</span>}
        </button>
      </div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl z-50 flex flex-col border border-gray-100 overflow-hidden"
            style={{ height: '500px', maxHeight: '80vh' }}
          >
            <div className="bg-primary-900 text-white p-4 font-medium flex justify-between items-center">
              <div>
                <p className="font-bold">Jay Beauty Support</p>
                <p className="text-xs text-gray-300">Typically replies right away</p>
              </div>
              <button onClick={() => setIsOpen(false)}>
                <X className="h-5 w-5 text-gray-300 hover:text-white" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 bg-gray-50">
              {messages.map((msg, idx) => (
                <div key={idx} className={`max-w-[85%] p-3 rounded-2xl ${msg.role === 'user' ? 'bg-accent-orange text-white self-end rounded-tr-sm' : 'bg-white text-gray-800 self-start shadow-sm rounded-tl-sm border border-gray-100'}`}>
                  <p className="text-sm leading-relaxed">{msg.text}</p>
                </div>
              ))}
              {isLoading && (
                <div className="bg-white text-gray-500 self-start p-3 rounded-2xl rounded-tl-sm shadow-sm border border-gray-100">
                  <p className="text-sm flex gap-1 items-center">
                    <span className="animate-bounce">.</span><span className="animate-bounce delay-100">.</span><span className="animate-bounce delay-200">.</span>
                  </p>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSend} className="p-3 bg-white border-t border-gray-100 flex items-center gap-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask us anything..." 
                className="flex-1 outline-none text-sm bg-gray-100 px-4 py-2.5 rounded-full"
              />
              <button 
                type="submit" 
                disabled={!input.trim() || isLoading}
                className="bg-primary-900 text-white p-2.5 rounded-full disabled:opacity-50 hover:bg-primary-800 transition-colors"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
