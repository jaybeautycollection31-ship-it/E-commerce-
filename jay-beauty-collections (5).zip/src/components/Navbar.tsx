import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { ShoppingBag, Search, Menu, User, X } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  
  const cart = useStore((state) => state.cart);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/shop?search=${encodeURIComponent(searchTerm.trim())}`);
      setIsSearchOpen(false);
      setSearchTerm('');
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-gray-600 hover:text-gray-900"
            >
              <Menu className="h-6 w-6" />
            </button>
            <Link to="/" className="ml-2 md:ml-0 flex items-center gap-2">
              <div className="w-10 h-10 overflow-hidden flex items-center justify-center rounded-sm transition-transform hover:scale-105">
                <img 
                  src="https://i.pinimg.com/736x/db/f8/2b/dbf82b4ce63f2a8bb38d4d1022586605.jpg" 
                  alt="Logo" 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="font-bold text-xl hidden sm:block tracking-tight text-primary-900">
                Jay Beauty Collections
              </span>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-600 hover:text-accent-orange font-medium transition-colors">Home</Link>
            <Link to="/shop" className="text-gray-600 hover:text-accent-orange font-medium transition-colors">Shop</Link>
            <Link to="/track" className="text-gray-600 hover:text-accent-orange font-medium transition-colors">Track Order</Link>
          </div>

          <div className="flex items-center space-x-4 md:space-x-6">
            <div className={`relative flex items-center ${isSearchOpen ? 'w-48 sm:w-64' : 'w-auto'} transition-all duration-300`}>
              {isSearchOpen ? (
                <form onSubmit={handleSearch} className="flex-1">
                  <input
                    autoFocus
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onBlur={() => !searchTerm && setIsSearchOpen(false)}
                    placeholder="Search products..."
                    className="w-full border border-gray-200 rounded-full px-4 py-1.5 text-sm focus:outline-none focus:border-accent-orange"
                  />
                  <button type="button" onClick={() => setIsSearchOpen(false)} className="absolute right-3 top-1.5 text-gray-400 hover:text-gray-600">
                    <X size={16} />
                  </button>
                </form>
              ) : (
                <button 
                  onClick={() => setIsSearchOpen(true)}
                  className="text-gray-600 hover:text-accent-orange transition-colors"
                >
                  <Search className="h-5 w-5" />
                </button>
              )}
            </div>
            
            <Link to="/auth" className="text-gray-600 hover:text-accent-orange transition-colors">
              <User className="h-5 w-5" />
            </Link>
            <Link to="/cart" className="text-gray-600 hover:text-accent-orange transition-colors relative group">
              <ShoppingBag className="h-5 w-5 group-hover:scale-110 transition-transform" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-accent-orange text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black/50" onClick={() => setIsMenuOpen(false)}>
          <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-xl p-6" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-8">
              <span className="font-bold text-lg">Menu</span>
              <button onClick={() => setIsMenuOpen(false)}>
                <X className="h-6 w-6 text-gray-500" />
              </button>
            </div>
            <div className="flex flex-col space-y-4">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium text-gray-900">Home</Link>
              <Link to="/shop" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium text-gray-900">Shop</Link>
              <Link to="/track" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium text-gray-900">Track Order</Link>
              <Link to="/auth" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium text-gray-900">Login / Register</Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
